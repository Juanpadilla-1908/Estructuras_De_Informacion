<?php

require "config/conex.php";

$id = $_POST["id"];
$Nombre = $_POST["nombre"];
$Celular = $_POST["celular"];

$sql = "UPDATE clientes 
SET 
nombre ='".$Nombre."',
celular = '".$Celular."'
WHERE 
id = ".$id."";

if ($dbh->query($sql))
{
    echo "Datos actualizados correctamente";
}else{
    echo "Los datos no se han podido actualizar";
}

?>