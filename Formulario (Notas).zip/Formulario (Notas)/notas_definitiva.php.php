<?php

require "Config/conex.php";

$name = $_POST["name"];
$c1 = $_POST["c1"];
$c2 = $_POST["c2"];
$c3 = $_POST["c3"];
$promedio = ($c1 * 0.3) + ($c2 * 0.3) + ($c3 * 0.4);

$sql = "INSERT INTO definitiva(nombre, corte1, corte2, corte3, definitiva) VALUES (:name, :c1, :c2, :c3, :promedio)";

try {
    $stmt = $dbh->prepare($sql);
    $stmt->execute([
        ':name' => $name,
        ':c1' => $c1,
        ':c2' => $c2,
        ':c3' => $c3,
        ':promedio' => $promedio
    ]);
    
    echo "✅ Su definitiva es: $promedio";
} catch (PDOException $e) {
    echo "❌ Error al guardar los datos: " . $e->getMessage();
}
?>