<?php

require 'config/conex.php';

$cantidad = $_POST ["hamburguesa2"]; 
$total = 7000 * $cantidad; 

$gaseosa = $_POST ["gaseosa"];

if($gaseosa == 1)
{
    $total = $total + ($gaseosa = 3500);
}

$sql = "INSERT INTO hamburguesasygaseosas(valor) VALUES (".$total.")";

if($dbh->query($sql))
{
    echo "Venta registrada: $".$total; 
}
else
{
    echo "Error en la venta";
}
?>